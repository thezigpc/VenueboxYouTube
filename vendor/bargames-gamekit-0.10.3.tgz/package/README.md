# @bargames/gamekit

Shared building blocks for the Bar Games family (Bingo, Pool, CAH). Each game still owns
its rules, its `Room` class, its screens and its look. The kit owns the plumbing they had
each copied: admin login, room bookkeeping, logging, JSON storage, socket and session
handling. It also wires all of that into a Bar Games box in one call.

- **Works standalone.** Nothing here needs a box. The optional box wiring
  (`@bargames/gamekit/bargames`) goes through `@bargames/sdk`, which is inert off a box.
- **No new runtime dependencies.** `express`, `react` and `@bargames/sdk` are peer
  dependencies the games already have. `socket.io` stays the game's own: pass its
  socket in.
- Node 22, ESM, TypeScript (NodeNext), like the games.

## Install (vendored, like the SDK)

Download the tarball from this repo's latest release into the game's `vendor/` folder:

```bash
gh release download --repo thezigpc/gamekit --pattern "*.tgz" --dir vendor --clobber
```

Then point both workspaces at it, and commit the tarball. CI and `docker build` must not
need GitHub access to this repo.

```jsonc
// server/package.json and client/package.json
"@bargames/gamekit": "file:../vendor/bargames-gamekit-0.5.1.tgz"
```

Run `npm install`, then commit `vendor/` and the lockfile. **Every release has a new
version number.** A changed tarball under the same name breaks `npm ci` in the games,
because the lockfile pins its integrity hash.

## What's in it

### `@bargames/gamekit/server`

| Export | Replaces (Bingo / Pool) |
|---|---|
| `createLogger`, `log` | `server/src/util/logger.ts` (same line format, `LOG_LEVEL` read per call, null fields skipped) |
| `createJsonStore(DATA_DIR)` | `admin/store.ts`, `util/jsonFileStore.ts`: `readResult` (missing / ok / **invalid, file left untouched**), `read`, atomic `write`, per-file serialized `update`, absolute paths for `*_PATH` env overrides |
| `createSettingStore`, `createPresetStore` | one-setting stores (game name, role names, default look) and named presets with one-time migration |
| `createAdminAuth({ store, envPassword, saltFormat })` | `admin/auth.ts`: scrypt, setup once, `ADMIN_PASSWORD` env, per-IP lockout, **global verification cap + queue + capped delay**, length-safe compares, sessions with TTL, **damaged file fails closed**. Transport-free: use it over HTTP or socket.io |
| `adminRouter({ auth, clientIp })` | the HTTP status, setup, login and logout part of `admin/routes.ts` (async errors handled); mount your own routes after it |
| `newRoomCode(len, alphabet)`, `normalizeRoomCode`, `newToken`, `newId`, `newSerial`, `cryptoRand` | `rooms/ids.ts` (crypto RNG) |
| `RoomRegistry<Room>`, `safeTimeout`, `installShutdown` | `rooms/RoomManager.ts`: cap, codes, idle sweep, close causes, crash containment, debounced `players_changed`, events, `overviews()`, shutdown on signals and crashes |
| `resolveTerms`, `normalizeTerm`, `fillTerms` | renameable terms (No Filter's role names), also exported from `/client` |

Your `Room` implements the small `KitRoom` interface: `code`, `kind`, `title`,
`createdAt`, `lastActivityAt`, `close(reason, cause)`, `playerCount()`, `tableCount()`,
and optionally `phase`, `round`, `hostConnected`, `hostName`, `maxPlayers` and
`pendingClaims`, each either a plain property or a method (so an existing `phase`
state property just works), or one `overviewExtra()` returning any of them. In return, every game's admin page and the venue box's **Rooms** page
get the same view of every room.

**Under a path prefix (kit 0.6.0, SDK 0.10.0):** the game works at
`https://venue.example.com/<game>/` as well as at the root. The proxy (the box gateway, or
yours) strips the prefix; the game is told it with `BG_BASE_PATH` (box) or `BASE_PATH`.

```ts
// server, after the API routes and socket.io
serveSpa(app, { dist: path.resolve(__dirname, "../../client/dist") });

// client
const dev = { vitePort: 5173, serverPort: 3000, override: import.meta.env.VITE_SERVER_URL };
fetch(`${serverBase(dev)}/api/config`);
const socket = io(serverOrigin(dev), { ...SOCKET_OPTIONS, path: socketPath() });
<BrowserRouter basename={basePath()}>…</BrowserRouter>
```
Vite: `base: "./"`. Keep links app-relative (router links, `serverBase`), never a bare
`"/api/…"` or `"/room/…"`.

**Staff sign-in through the venue box (kit 0.4.0, SDK 0.7.0):** staff signed in to the
box's admin open the game's settings from the box without the game's password.

```ts
// server
const admin = adminRouter({ auth, clientIp, trusted: (req) => bg.isStaff(req) });
// client (admin page, before showing the password form)
import { staffSignIn } from "@bargames/gamekit/client";
const token = await staffSignIn(serverUrl);
if (token) useThisAdminToken(token);
```

**The box's password works here too (kit 0.5.0, SDK 0.8.0):**
`createAdminAuth({ ..., venuePassword: (pw, ip) => bg.checkVenuePassword(pw, ip), onBox: bg.connected })`.
With `onBox` (kit 0.5.1) the box's password takes over: `/status` returns `venueLogin: true`
(show the sign-in form, not first-run setup) and `setupAllowed` (only staff the box vouches
for may set a separate game password; `/setup` refuses anyone else).

Declare the admin page in `bargames.json` as `routes.admin` (e.g. `"/admin"`): the box's
Games/Apps tab links to it. Off a box `bg.isStaff` is always false, so nothing changes.

**Password files from before the kit:** Bingo and Pool derived keys with the salt's
bytes (`saltFormat: "bytes"`, the default); No Filter used the hex string itself
(`saltFormat: "string"`). Set it to match the game's existing `admin.json`, or every
live admin is locked out. New hashes are written in that same format and record it in
the file, so rolling a deployment back to pre-kit code still reads them.

**Per-IP lockout behind Cloudflare:** standalone, a whole venue's Wi-Fi shares one
public IP, so the default lockout (10 failures / 15 min per IP) lets any guest lock the
real admin out. Games deployed that way pass `failsAllowed: Infinity` and rely on the
global cap and capped delay. On a Bar Games box `clientIp` is each device's own address,
so the default is fine there.

**Crash containment:** the registry passes `ctx` to your factory. A room calls
`ctx.close(reason)` (cause `"error"`) when its own logic fails; `safeTimeout(label, ms,
fn, (err) => ctx.close(...))` does that for timers. Only that room closes. A room whose
idle check throws is dropped, not retried forever.

```ts
const store = createJsonStore(DATA_DIR);
const auth = createAdminAuth({ store, envPassword: ADMIN_PASSWORD });
await auth.init();

const rooms = new RoomRegistry<Room>({
  create: (code, kind, ctx) => new Room(code, transport, kind, ctx),
  maxRooms: MAX_ROOMS,              // Infinity for no cap
  codeLength: 5, codeAlphabet: SERIAL_ALPHABET,   // optional; default 4 letters
  idleMinutes: () => settings.get().roomIdleMinutes,   // read fresh every sweep
  fullError: () => new GameError("ROOM_FULL"),
  joinPath: (r) => `/join/${r.code}`,  // SDK 0.4.0: "Join" on the venue's games list (never for private rooms)
});

const admin = adminRouter({ auth, clientIp });
admin.get("/overview", (_req, res) => res.json({ rooms: rooms.overviews(), settings: settings.get() }));
app.use("/api/admin", admin);

installShutdown(rooms, {                                // SIGTERM, SIGINT, crashes
  flush: () => bg.flush(),
  restartReason: "Updating, back in a moment.",          // deploys
  crashReason: "Something went wrong. Please rejoin.",    // crashes (rooms close with cause "error")
  drainMs: 400,                                           // let "room closed" reach phones first
  beforeExit: () => io.close(),   // not httpServer.close(): it waits on every open WebSocket
});
// On joins, leaves and kicks (not reconnects): rooms.notePlayers(room)
//   (0.3.2: no event when a join and a leave cancel out; no timers when nothing listens)
// To seat the creator before room_created fires: rooms.create("patron", (room) => room.addPlayer(...))
```

### `@bargames/gamekit/bargames`

```ts
wireBarGames(bg, rooms, {
  createVenueRoom: ({ title }) => {
    const room = rooms.create("venue", (r) => (r.title = title));
    // Bingo: an empty host seat. If your host is also a player (No Filter's Judge), DON'T
    // add a seat: give the room a host key for a controller screen instead.
    const key = room.makeHostKey();
    return { room, hostUrl: `/room/${room.code}?role=table&display=1&key=${key}` };
  },
  commands: {
    start: (room) => room.startFromBox(),      // throw or return { ok:false } to refuse
    pause: (room) => room.pauseFromBox(),
    resume: (room) => room.resumeFromBox(),
    next_round: (room) => room.nextRoundFromBox(),
  },
  claims: {                                     // games with claims only (Bingo)
    confirm: (room, id) => room.resolveClaim(id, true),
    reject: (room, id, reason) => room.resolveClaim(id, false, reason),
  },
  claimMessages: { gone: "That bingo was already called.", none: "Nobody has called bingo." },  // 0.3.2, optional
  endCause: "host",                             // 0.3.2: cause recorded when the box ends a room (default "admin")
});
```

That one call:
- sets the status provider from `rooms.overviews()`;
- emits `room_created`, `room_closed` (however it closes) and debounced `players_changed`;
- calls commands with `ctx.actor === "venue"`: the box acts as the venue, never as a seat;
- handles `end` (closes the room like an admin close; the box may pass a reason);
- wraps every command so an unknown room or a throw becomes `{ ok: false, message }`;
- resolves an omitted `claimId` to the oldest pending claim;
- off a box (`bg.connected` false) doesn't listen to the registry at all, so standalone
  games run no player-count timers.

List the matching `commands` and `events` in `bargames.json` as before.

### `@bargames/gamekit/client` (React 18)

| Export | Replaces |
|---|---|
| `createSessionStore("bingo")` | `client/src/session.ts`: per-tab seat, per-device prefs (`pref`, `json`); storage errors never throw |
| `serverOrigin({ vitePort, serverPort, override })`, `SOCKET_OPTIONS`, `createCall(socket)` | `client/src/socket.ts`; `override` = `import.meta.env.VITE_SERVER_URL`. Failed calls reject with `CallError` (`message`, `code`), whether the ack's error is a string or `{ code, message }` |
| `SOCKET_SERVER_OPTIONS` | server-side `pingInterval` 10 s / `pingTimeout` 5 s: half-open phones noticed in ~15 s. Also exported from `/server` (no React) |
| `useRoomConnection(code, { socket, call, sessions, … })` | `client/src/useRoom.ts`. Options for other protocols: `events`, `resumeArgs(session)`, `onResumed(ack)`, `parseClosed(payload)`, `serverTime(view)` |
| `ErrorBoundary` | `client/src/ErrorBoundary.tsx` (`classNames` / `fallback` keep each game's look) |
| `usePublicConfig(serverUrl, parse)`, `useGameName`, `invalidatePublicConfig()`, `useVenue`, `VenueBranding` | one cached `/api/config` fetch shared by every hook; call `invalidatePublicConfig()` after an in-app admin save so mounted hooks refetch |
| `<BackToGames ctx={venue} />`, `<VenueAnnouncement ctx={venue} hidden? />` | SDK 0.4.0, on a box only (render nothing standalone). `BackToGames`: "← All games" + "Also playing: …", at the bottom of the **landing page only**. `VenueAnnouncement`: the staff's announcement, once at the root of the phone app, pre-join pages included. It hides itself on pages the SDK marks as shared screens (0.5.0's `tableMode()` / `markSharedScreen()`); on SDK 0.4.0 pass `hidden` there. Text uses `--venue-on-primary`. `venue` is `useVenue(serverUrl)` |
| `<JoinAddress url={ctx.game.publicUrl} />`, `<JoinBox qr code url maxWidth? />` | 0.7.3. "Join at <address>" under a QR code that fits any venue address: no scheme, a break after each "." and "/", smaller text for long ones, never overflows. Set the box width per layout with `--join-max-width` (JoinBox) or your own CSS. Works standalone (shows `localhost:…`) |
| `new HostSeats({ firstJoinerHosts })` (server), `wireBarGames(..., { seats })` | 0.8.0. Who may host a room: the first-joiner offer (closed by any host-seat attach), staff take-over (old host becomes co-host), single-use expiring co-host invites. Answers SDK 0.14.0's host_link / cohost_link / remove_cohost |

```ts
// client/src/socket.ts
import { io } from "socket.io-client";
import { createCall, serverOrigin, SOCKET_OPTIONS } from "@bargames/gamekit/client";
export const serverUrl = serverOrigin({ vitePort: 5174, serverPort: 3002 });
export const socket = io(serverUrl, SOCKET_OPTIONS);
export const call = createCall(socket);
```

### On-screen keyboard (kit 0.10.0)

Touchscreens plugged into the box (and venue clients in touch mode) have no keyboard of
their own. Mount the kit's once, near the root:

```tsx
import { OnScreenKeyboard } from "@bargames/gamekit/client";

<App />
<OnScreenKeyboard />
```

It's hidden everywhere else. Use real `<input>`s with `maxLength` and `inputMode`
(`"numeric"` gets a number pad) and a `<form onSubmit>` so Enter works. Test it on a PC
with `?bg_keyboard=1` (and `?bg_keyboard=0` to stop).

## Adopting it in a game

Do one area at a time, keeping the game's tests green after each:
1. logger and store;
2. admin auth and routes;
3. ids and the room registry;
4. box wiring;
5. client.

Delete each replaced file in the same commit. Standalone behaviour must stay the same:
- the same admin password file (`admin.json` in `DATA_DIR`), so existing passwords keep working;
- the same room-code alphabet and length;
- the same idle default;
- the same socket event names.

`useRoomConnection` defaults to `resume`, `state` and `closed`.

## Developing the kit

```bash
npm install
npm test            # node:test via tsx
npm run pack:vendor # build + dist-pack/bargames-gamekit-<version>.tgz
```

To release, bump `version` in `package.json`, add a `CHANGELOG.md` entry, commit, tag
`v<version>`, then attach the tarball to a GitHub release:

```bash
gh release create v0.3.1 dist-pack/bargames-gamekit-0.3.1.tgz --notes-file CHANGELOG.md
```

The kit vendors the SDK tarball it is built against (`vendor/`). Update it when the SDK
version changes.
